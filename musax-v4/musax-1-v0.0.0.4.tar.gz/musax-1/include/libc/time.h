#ifndef LIBC_TIME_H
#define LIBC_TIME_H

typedef long long time_t;

struct tm {
    int tm_sec;
    int tm_min;
    int tm_hour;
    int tm_mday;
    int tm_mon;
    int tm_year;
    int tm_wday;
    int tm_yday;
    int tm_isdst;
};

time_t timegm(struct tm *broken_down);
struct tm *gmtime_r(const time_t *timer, struct tm *result);

#endif
